from django.contrib import admin
from .models import Food,User,FoodCat,Order
# Register your models here.
admin.site.register(Food)
admin.site.register(User)
admin.site.register(FoodCat)
admin.site.register(Order)
