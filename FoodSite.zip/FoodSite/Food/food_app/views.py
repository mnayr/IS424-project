from django.shortcuts import render
from django.http import HttpResponse
from .models import User,Food,Basket,Order
# Create your views here.

def login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = User.objects.filter(password = password,username=username)
        if user:
            id=  user[0].id
            request.session["user_id"] = id
            food_for_offer = Food.objects.filter(issOffer=True)
            if food_for_offer:
                return render(request,'home.html',{"food_for_offer":food_for_offer})
            else:
                 return render(request,'home.html',{"empty":"Food is empty"})

        else:
            return render(request,'login.html')
    elif request.method=="GET":
        return render(request,'login.html')

def signup(request):
    if request.method == "POST":
        fullname = request.POST["fullname"]
        email = request.POST["email"]
        username = request.POST["username"]
        password = request.POST["password"]
        user = User(
            fullname =  fullname,
            email =  email,
            username =  username,
            password =  password
            )
        user.save()
        user = User.objects.filter(password = password,username=username)
        id=  user[0].id
        request.session["user_id"] = id
        food_for_offer = Food.objects.filter(issOffer=True)
        if food_for_offer:
                return render(request,'home.html',{"food_for_offer":food_for_offer})
        else:
                return render(request,'home.html',{"empty":"Food is empty"})
    elif request.method=="GET":
        return render(request,'signup.html')

def home(request):
    food_for_offer = Food.objects.filter(issOffer=True)
    if food_for_offer:
                return render(request,'home.html',{"food_for_offer":food_for_offer})
    else:
                return render(request,'home.html',{"empty":"Food is empty"})

def food(request):
    food = Food.objects.select_related('cat_id').all()
    return render(request,'food.html',{"food":food})

def selectFood(request):
    user_id = request.session["user_id"]
    user = User.objects.filter(id=user_id)
    id = request.GET["id"]
    food = Food.objects.filter(id=id)
    basket = Basket(
            food_id =  food[0],
            user_id =  user[0]
            )
    basket.save()
    food = Food.objects.select_related('cat_id').all()
    return render(request,'food.html',{"food":food})


def search(request):
    name = request.GET["name"]
    food = Food.objects.filter(name=name)
    if food:
        f = food[0]
        return render(request,'search_res.html',{"food":f})
    else:
        return render(request,'home.html')
def removeBasketCon(request):
    user_id = request.session["user_id"]
    Basket.objects.filter(user_id=user_id).delete()
    return render(request,'basket.html')

def addToOrder(request):
    user_id = request.session["user_id"]
    user = User.objects.filter(id=user_id)
    basket = Basket.objects.filter(user_id=user_id)
    total_price = 0
    for tmp in basket:
        total_price = total_price + tmp.food_id.price
    order = Order(
            total_price=total_price,
            user_id=user[0]
        )
    order.save()
    Basket.objects.filter(user_id=user_id).delete()
    return render(request,'basket.html')
def foodData(request):
    id = request.GET["id"]
    food = Food.objects.filter(id=id)
    return render(request,'food_data.html',{"food":food[0]})

def basket(request):
    user_id = request.session["user_id"]
    basket = Basket.objects.select_related('food_id').filter(user_id=user_id)
    total_price = 0
    for tmp in basket:
        total_price = total_price + tmp.food_id.price
    return render(request,'basket.html',{"basket":basket,"total_price":total_price})

def order(request):
    user_id = request.session["user_id"]
    order = Order.objects.filter(user_id=user_id)
    return render(request,'order.html',{"order":order})




        




