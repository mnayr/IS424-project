from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path("",views.home,name="home"),
    path("login",views.login,name="login"),
    path("signup",views.signup,name="signup"),
    path("home",views.home,name="home"),
    path("food",views.food,name="food"),
    path("foodData",views.foodData,name="foodData"),
    path("basket",views.basket,name="basket"),
    path("order",views.order,name="order"),
    path("selectFood",views.selectFood,name="selectFood"),
    path("removeBasketCon",views.removeBasketCon,name="removeBasketCon"),
    path("addToOrder",views.addToOrder,name="addToOrder"),
    path("search",views.search,name="search")


]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)