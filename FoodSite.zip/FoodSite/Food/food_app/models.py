from django.db import models

class User(models.Model):
    id= models.AutoField(primary_key = True)
    fullname =  models.CharField(max_length = 70)
    email =  models.CharField(max_length = 70)
    username =  models.CharField(max_length = 70)
    password =  models.CharField(max_length = 70)


class FoodCat(models.Model):
    id= models.AutoField(primary_key = True)
    cat =  models.CharField(max_length = 40)

    class Meta: 
        verbose_name_plural = "Food Categories"

class Food(models.Model):
    id= models.AutoField(primary_key = True)
    name =  models.CharField(max_length = 40)
    price =  models.DecimalField(max_digits = 10,decimal_places=2)
    des =  models.TextField(default = "")
    issOffer =  models.BooleanField(default = False)
    cat_id = models.ForeignKey(FoodCat, null=True, on_delete=models.CASCADE)
    image=models.ImageField(null=True,blank=True)

class Basket(models.Model):
    id= models.AutoField(primary_key = True)
    food_id = models.ForeignKey(Food, null=True, on_delete=models.CASCADE)
    user_id = models.ForeignKey(User, null=True, on_delete=models.CASCADE)

class Order(models.Model):
    id= models.AutoField(primary_key = True)
    total_price =  models.DecimalField(max_digits = 10,decimal_places=2)
    user_id = models.ForeignKey(User, null=True, on_delete=models.CASCADE)
